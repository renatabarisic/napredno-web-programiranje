INSERT INTO data (data1, data2, data3)
VALUES ('1', '12', '123');
